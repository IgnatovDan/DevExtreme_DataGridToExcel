﻿import React from 'react';
import DataGrid, { Export } from 'devextreme-react/ui/data-grid';
import { customers } from './data.js';

class App extends React.Component {
  customizeExcelCell(options) {
    switch (options.gridCell.rowType) {
      case 'header':
        options.horizontalAlignment = 'left';
        options.verticalAlignment = 'center';
        options.wrapTextEnabled = false;
        break;
      case 'data':
        options.horizontalAlignment = 'right';
        options.verticalAlignment = 'bottom';
        options.wrapTextEnabled = true;
        break;
    }
  }
  render() {
    return (
      <DataGrid
        dataSource={customers}
        columns={['CompanyName', 'City', 'State', 'Phone', 'Fax']}
        showBorders={true}>
        <Export enabled={true} customizeExcelCell={this.customizeExcelCell} />
      </DataGrid>
    );
  }
}

export default App;
