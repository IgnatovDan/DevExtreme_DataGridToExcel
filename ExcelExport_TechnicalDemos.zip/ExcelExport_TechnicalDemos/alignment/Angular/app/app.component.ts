import { NgModule, Component, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { DxDataGridModule } from 'devextreme-angular';
import { Customer, Service } from './app.service';

if(!/localhost/.test(document.location.host)) {
    enableProdMode();
}

@Component({
    selector: 'demo-app',
    templateUrl: 'app/app.component.html',
    providers: [Service]
})
export class AppComponent {
    customers: Customer[];

    constructor(service: Service) {
        this.customers =  service.getCustomers();
    }
    customizeExcelCell(options) {
        switch(options.gridCell.rowType) {
            case 'header':
                options.horizontalAlignment = 'left';
                options.verticalAlignment = 'center';
                options.wrapTextEnabled = false;
                break;
            case 'data':
                options.horizontalAlignment = 'right';
                options.verticalAlignment = 'bottom';
                options.wrapTextEnabled = true;
                break;
        } 
    }
}

@NgModule({
    imports: [
        BrowserModule,
        DxDataGridModule
    ],
    declarations: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);