<template>
  <dx-data-grid
    id="gridContainer"
    :data-source="dataSource"
    :columns="columns"
    :show-borders="true">
    <dx-export :enabled="true" :customize-excel-cell="customizeExcelCell"/>
  </dx-data-grid>
</template>
<script>

import { DxDataGrid, DxExport } from 'devextreme-vue/ui/data-grid';
import { customers } from './data.js';

export default {
  components: {
    DxDataGrid,
    DxExport
  },
  data() {
    return {
      dataSource: customers,
      columns: ['CompanyName', 'City', 'State', 'Phone', 'Fax']
    };
  },
  methods: {
    customizeExcelCell(options) {
      switch (options.gridCell.rowType) {
        case 'header':
          options.horizontalAlignment = 'left';
          options.verticalAlignment = 'center';
          options.wrapTextEnabled = false;
          break;
        case 'data':
          options.horizontalAlignment = 'right';
          options.verticalAlignment = 'bottom';
          options.wrapTextEnabled = true;
          break;
      }
    }
  }
};
</script>
