import { Injectable } from '@angular/core';

export class Task {
    Caption: number;
    Status: string;
}

let tasks = [
  { caption: 'Not started task' },
  { caption: 'Overdue task', status: 'overdue' },
  { caption: 'Completed task', status: 'completed' },
  { caption: 'In progress task', status: 'inProgress' },
];

@Injectable()
export class Service {
    getTasks() {
      return tasks;
    }
}
