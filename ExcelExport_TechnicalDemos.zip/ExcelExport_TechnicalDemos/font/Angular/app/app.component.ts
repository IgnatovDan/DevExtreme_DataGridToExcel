import { NgModule, Component, enableProdMode } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { platformBrowserDynamic } from "@angular/platform-browser-dynamic";
import { DxDataGridModule } from "devextreme-angular";
import { Customer, Service } from "./app.service";

@Component({
  styleUrls: ["./app.component.css"],
  selector: "demo-app",
  templateUrl: "./app.component.html",
  providers: [Service]
})
export class AppComponent {
  tasks: Task[];

  constructor(service: Service) {
    this.tasks = service.getTasks();
  }
  onCellPrepared(e) {
    if (
      e.rowType === "data" &&
      e.column.dataField === "caption" &&
      e.data.status
    ) {
      debugger;
      e.cellElement.classList.add(e.data.status);
    }
  }
  customizeExcelCell(options) {
    const excelFonts = {
      overdue: { color: '#FF0000', size: 14, bold: true, underline: 'single' },
      completed: { color: '#00FF00', size: 8 },
      inProgress: { color: '#0000FF', size: 11, italic: true },
    };
    if (options.gridCell.rowType === 'data' && options.gridCell.column.dataField === 'caption') {
      const font = excelFonts[options.gridCell.data.status];
      if (font) {
        options.font = font;
      }
    }
  }
}

@NgModule({
  imports: [BrowserModule, DxDataGridModule],
  declarations: [AppComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}

platformBrowserDynamic().bootstrapModule(AppModule);
