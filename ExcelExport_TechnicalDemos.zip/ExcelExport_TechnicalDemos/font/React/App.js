﻿import React from 'react';
import DataGrid, { Export } from 'devextreme-react/ui/data-grid';
import { tasks } from './data.js';
import './styles.css';

class App extends React.Component {
  cellPrepared(e) {
    if (e.rowType === 'data' && e.column.dataField === 'caption' && e.data.status) {
      debugger;
      e.cellElement.classList.add(e.data.status);
    }
  }
  customizeExcelCell(options) {
    const excelFonts = {
      overdue: { color: '#FF0000', size: 14, bold: true, underline: 'single' },
      completed: { color: '#00FF00', size: 8 },
      inProgress: { color: '#0000FF', size: 11, italic: true },
    };
    if (options.gridCell.rowType === 'data' && options.gridCell.column.dataField === 'caption') {
      const font = excelFonts[options.gridCell.data.status];
      if (font) {
        options.font = font;
      }
    }
  }
  render() {
    return (
      <DataGrid
        dataSource={tasks}
        columns={['caption', 'status']}
        showBorders={true}
        onCellPrepared={this.cellPrepared}>
        <Export enabled={true} customizeExcelCell={this.customizeExcelCell} />
      </DataGrid>
    );
  }
}

export default App;
