<template>
  <dx-data-grid
    id="gridContainer"
    :data-source="dataSource"
    :columns="columns"
    :show-borders="true"
    @cellPrepared="cellPrepared">
    <dx-export :enabled="true" :customize-excel-cell="customizeExcelCell"/>
  </dx-data-grid>
</template>
<script>

import { DxDataGrid, DxExport } from 'devextreme-vue/ui/data-grid';
import { tasks } from './data.js';

export default {
  components: {
    DxDataGrid,
    DxExport
  },
  data() {
    return {
      dataSource: tasks,
      columns: ['caption', 'status']
    };
  },
  methods: {
    cellPrepared(e) {
        if(e.rowType === 'data' && e.column.dataField === 'caption' && e.data.status) {
            e.cellElement.classList.add(e.data.status);
        }
    },
    customizeExcelCell(options) {
        const excelFonts = {
            overdue: { color: 'FFFF0000', size: 14, bold: true, underline: 'single' },
            completed: { color: 'FF00FF00', size: 8 },
            inProgress: { color: 'FF0000FF', size: 11, italic: true },
        };

      if(options.gridCell.rowType === 'data' && options.gridCell.column.dataField === 'caption') {
          const font = excelFonts[options.gridCell.data.status];
          if(font) {
              options.font = font;
          }
      }
    }
  }
};
</script>
<style>
.overdue {
    color: #FF0000;
    font-weight: bold;
    text-decoration-line: underline
}
.completed {
    color: #00FF00;
    font-size: x-small
}
.inProgress {
    color: #0000FF;
    font-style: italic;
}
</style>
