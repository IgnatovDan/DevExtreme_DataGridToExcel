<template>
  <dx-data-grid
    id="gridContainer"
    :data-source="dataSource"
    :columns="columns"
    :show-borders="true"
    @cellPrepared="cellPrepared">
    <dx-export :enabled="true" :customize-excel-cell="customizeExcelCell"/>
  </dx-data-grid>
</template>
<script>

import { DxDataGrid, DxExport } from 'devextreme-vue/ui/data-grid';
import { tasks } from './data.js';

export default {
  components: {
    DxDataGrid,
    DxExport
  },
  data() {
    return {
      dataSource: tasks,
      columns: ['caption', 'status']
    };
  },
  methods: {
    cellPrepared(e) {
        if(e.rowType === 'data' && e.column.dataField === 'caption' && e.data.status) {
          debugger;
            e.cellElement.classList.add(e.data.status);
        }
    },
    customizeExcelCell(options) {
      const excelFillStyles = {
          overdue: {
              backgroundColor: '#FF0000'
          },
          completed: {
              backgroundColor: '#00FF00'
          },
          inProgress: {
              backgroundColor: '#FFFF00',
              fillPatternType: 'darkVertical',
              fillPatternColor: '#00FF00'
          }
      };

      if(options.gridCell.rowType === 'data' && options.gridCell.column.dataField === 'caption') {
          const patternFill = excelFillStyles[options.gridCell.data.status];
          if(patternFill) {
              Object.assign(options, patternFill);
          }
      }
    }
  }
};
</script>
<style>
.overdue {
    background-color: #FF0000
}
.completed {
    background-color: #00FF00
}
.inProgress {
    background: repeating-linear-gradient(
        to right,
        #FFFF00,
        #FFFF00 2px,
        #00FF00 2px,
        #00FF00 4px
        );
}
</style>
