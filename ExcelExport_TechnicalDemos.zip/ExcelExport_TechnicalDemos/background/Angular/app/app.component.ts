import { NgModule, Component, enableProdMode } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { DxDataGridModule } from 'devextreme-angular';
import { Customer, Service } from './app.service';

if(!/localhost/.test(document.location.host)) {
    enableProdMode();
}

@Component({
    selector: 'demo-app',
    templateUrl: 'app/app.component.html',
    styleUrls: ['app/app.component.css'],
    providers: [Service]
})
export class AppComponent {
    customers: Customer[];

    constructor(service: Service) {
        this.customers =  service.getCustomers();
    }
    onCellPrepared (e) {
        if(e.rowType === 'data' && e.column.dataField === 'caption' && e.data.status) {
            e.cellElement.classList.add(e.data.status);
        }
    }
    customizeExcelCell(options) {
        const excelFillStyles = {
            overdue: {
                backgroundColor: '#FF0000'
            },
            completed: {
                backgroundColor: '#00FF00'
            },
            inProgress: {
                backgroundColor: '#FFFF00',
                fillPatternType: 'darkVertical',
                fillPatternColor: '#00FF00'
            }
        };

        if(options.gridCell.rowType === 'data' && options.gridCell.column.dataField === 'caption') {
            const patternFill = excelFillStyles[options.gridCell.data.status];
            if(patternFill) {
                Object.assign(options, patternFill);
            }
        }
    }
}

@NgModule({
    imports: [
        BrowserModule,
        DxDataGridModule
    ],
    declarations: [AppComponent],
    bootstrap: [AppComponent]
})
export class AppModule { }

platformBrowserDynamic().bootstrapModule(AppModule);