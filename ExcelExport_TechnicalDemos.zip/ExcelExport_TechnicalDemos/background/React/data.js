export const tasks = [
                    { caption: 'Not started task' },
                    { caption: 'Overdue task', status: 'overdue' },
                    { caption: 'Completed task', status: 'completed' },
                    { caption: 'In progress task', status: 'inProgress' },
                ];
