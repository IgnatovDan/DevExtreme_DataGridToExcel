﻿import React from 'react';
import DataGrid, { Export } from 'devextreme-react/ui/data-grid';
import { tasks } from './data.js';

class App extends React.Component {
  customizeExcelCell(options) {
    if(options.gridCell.rowType === 'data' && options.gridCell.column.dataField === 'caption') {
      const patternFill = excelFillStyles[options.gridCell.data.status];
      if(patternFill) {
        Object.assign(options, patternFill);
      }
    }
  }
  render() {
    return (
      <DataGrid
        dataSource={tasks}
        columns={['caption', 'status']}
        showBorders={true}>
        <Export enabled={true} customizeExcelCell={this.customizeExcelCell} />
      </DataGrid>
    );
  }
}

const excelFillStyles = {
  overdue: {
    backgroundColor: '#FF0000'
  },
  completed: {
    backgroundColor: '#00FF00'
  },
  inProgress: {
    backgroundColor: '#FFFF00',
    fillPatternType: 'darkVertical',
    fillPatternColor: '#00FF00'
  }
};            

export default App;
